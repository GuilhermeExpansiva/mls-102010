declare module "_102010_designSystem" {
    import { IDesignSystemTokens } from './_100554_designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
